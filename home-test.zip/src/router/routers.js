import Main from "@views/Main.vue";

export default [
    {
        path: "/",
        name: "_home",
        redirect: "/home",
        component: Main,
        meta: {
            hideInMenu: true,
            notCache: true
        },
        children: [
            {
                path: "/home",
                name: "home",
                meta: {
                    hideInMenu: true,
                    title: "首页",
                    notCache: true,
                    icon: "md-home"
                },
                component: () => import("@pages/ImageList")
            }
        ]
    },
    {
        path: "",
        name: "doc",
        meta: {
            title: "文档",
            href: "https://lison16.github.io/iview-admin-doc/#/",
            icon: "ios-book"
        }
    }
];
