import {
    getBreadCrumbList,
    setTagNavListInLocalstorage,
    getMenuByRouter,
    getTagNavListFromLocalstorage,
    getHomeRoute,
    getNextRoute,
    routeHasExist,
    routeEqual,
    getRouteTitleHandled,
    localSave,
    localRead
} from "@/libs/util";

import config from "@utils/config";
const { homeName } = config;

export default {
    setBreadCrumb(state, route) {
        state.breadCrumbList = getBreadCrumbList(route, state.homeRoute);
    },
    setHomeRoute(state, routes) {
        state.homeRoute = getHomeRoute(routes, homeName);
    },
    setTagNavList(state, list) {
        let tagList = [];
        if (list) {
            tagList = [...list];
        } else tagList = getTagNavListFromLocalstorage() || [];
        if (tagList[0] && tagList[0].name !== homeName) tagList.shift();
        let homeTagIndex = tagList.findIndex(item => item.name === homeName);
        if (homeTagIndex > 0) {
            let homeTag = tagList.splice(homeTagIndex, 1)[0];
            tagList.unshift(homeTag);
        }
        state.tagNavList = tagList;
        setTagNavListInLocalstorage([...tagList]);
    }
};
