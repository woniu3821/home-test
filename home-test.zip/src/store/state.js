export default {
    access: "",
    tagNavList: [],
    breadCrumbList: [],
    homeRoute: {},
    user: {
        avatarImgPath: require("@assets/img/empty.png"),
        unreadCount: 30
    }
};
