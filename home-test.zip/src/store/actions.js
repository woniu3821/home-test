import ajax from "@utils/ajax";
import {} from "./types";
import { awaitWrap } from "@utils";

import {} from "@api/service";

import { Message } from "iview";

export default {};
