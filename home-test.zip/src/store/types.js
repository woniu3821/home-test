//获取私有云应用分类
export const GET_PRIVATE_CATEGORY = "GET_PRIVATE_CATEGORY";

//检查私有云api
export const CHECK_PRIVATE_API = "CHECK_PRIVATE_API";
