
<template>
    <div class="layout">
        <!-- 头部开始 -->
        <header class="layout__header">
            <Menu
                mode="horizontal"
                active-name="1"
            >
                <div class="header__content">
                    <div class="logo-con">
                        <img
                            :src="maxLogo"
                            key="max-logo"
                        />
                    </div>
                    <div class="layout-nav">
                        <nav>
                            <MenuItem name="1">
                            <Icon type="ios-navigate"></Icon>
                            Item 1
                            </MenuItem>
                            <MenuItem name="2">
                            <Icon type="ios-keypad"></Icon>
                            Item 2
                            </MenuItem>
                            <MenuItem name="3">
                            <Icon type="ios-analytics"></Icon>
                            Item 3
                            </MenuItem>
                            <MenuItem name="4">
                            <Icon type="ios-paper"></Icon>
                            Item 4
                            </MenuItem>
                        </nav>
                        <user
                            :message-unread-count="unreadCount"
                            :user-avatar="userAvatar"
                        />
                    </div>
                </div>

            </Menu>
        </header>
        <!-- 头部结束 -->
        <div class="layout__container">
            <aside class="container__aside">
                <Sider
                    hide-trigger
                    collapsible
                    :width="256"
                    :collapsed-width="64"
                    v-model="collapsed"
                    class="left-sider"
                    :style="{overflow: 'hidden'}"
                >
                    <side-menu
                        accordion
                        ref="sideMenu"
                        :active-name="$route.name"
                        :collapsed="collapsed"
                        @on-select="turnToPage"
                        :menu-list="menuList"
                    >
                        <!-- 需要放在菜单上面的内容，如Logo，写在side-menu标签内部，如下 -->
                    </side-menu>
                </Sider>
            </aside>
            <div class="container__content">
                <div class="content__bread">
                    <header-bar :collapsed="collapsed">

                    </header-bar>
                </div>
                <div class="content__mian">
                    <keep-alive :include="cacheList">
                        <router-view />
                    </keep-alive>
                </div>
            </div>
        </div>
    </div>
</template>
<script>

import SideMenu from '@/components/side-menu';
import HeaderBar from '@/components/header-bar'
import User from '@/components/user'
import { mapMutations } from 'vuex'
import routers from '@/router/routers'
export default {
    components: {
        SideMenu,
        HeaderBar,
        User
    },
    data () {
        return {
            collapsed: false,
            maxLogo: require('@assets/img/cp-logo-old.png')
        }
    },
    watch: {
        '$route' (newRoute) {
            const { name, query, params, meta } = newRoute
            this.addTag({
                route: { name, query, params, meta },
                type: 'push'
            })
            this.setBreadCrumb(newRoute)
            //   this.setTagNavList(getNewTagList(this.tagNavList, newRoute))
            this.$refs.sideMenu.updateOpenName(newRoute.name)
        }
    },
    computed: {
        userAvatar () {
            return this.$store.state.user.avatarImgPath
        },
        unreadCount () {
            return this.$store.state.user.unreadCount
        },
        tagNavList () {
            return this.$store.state.tagNavList
        },
        menuList () {
            return this.$store.getters.menuList
        },
        cacheList () {
            const list = ['ParentView', ...this.tagNavList.length ? this.tagNavList.filter(item => !(item.meta && item.meta.notCache)).map(item => item.name) : []]
            return list
        },
        style_sider () {
            return {
                // background: '#fff',
                height: '100%',
                overflow: 'hidden'
            }
        },
        menuitemClasses: function () {
            return [
                'menu-item',
                this.collapsed ? 'collapsed-menu' : ''
            ]
        },

    },
    methods: {
        ...mapMutations([
            'setBreadCrumb',
            'setTagNavList',
            'addTag',
            'setLocal',
            'setHomeRoute',
            'closeTag'
        ]),
        turnToPage (route) {
            let { name, params, query } = {}
            if (typeof route === 'string') name = route
            else {
                name = route.name
                params = route.params
                query = route.query
            }
            if (name.indexOf('isTurnByHref_') > -1) {
                window.open(name.split('_')[1])
                return
            }
            this.$router.push({
                name,
                params,
                query
            })
        },
    },
    mounted () {
        // this.setTagNavList()
        this.setHomeRoute(routers)
        this.setBreadCrumb(this.$route)
    }
}
</script>

<style scoped lang="stylus">
.layout {
    height: 100vh;
    display: flex;
    flex-direction: column;
    background: #E0E6ED;
    overflow: hidden;
    .layout__header {
        .header__content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 0 20px;
            .layout-nav {
                display: flex;
                align-items: center;
                nav {
                    margin-right: 20px;
                }
            }
            .logo-con {
                height: 64px;
                padding: 10px;
                img {
                    height: 44px;
                    width: auto;
                    display: block;
                    margin: 0 auto;
                }
            }
        }
    }
    &__container {
        flex-grow: 1;
        display: flex;
        align-items: stretch;
        .container__aside {
            background: #011529;
            flex-shrink: 0;
        }
        .container__content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            height: calc(100vh - 61px);
            overflow: hidden;
            .content__bread {
                padding: 10px 0;
            }
            .content__mian {
                margin: 0 10px 10px;
                flex-grow: 1;
                background: #fff;
                padding: 10px;
                border-radius: 5px;
                overflow-y: auto;
            }
        }
    }
}
.layout-logo {
    width: 100px;
    height: 30px;
    background: #5b6270;
    border-radius: 3px;
    float: left;
    position: relative;
    top: 15px;
    left: 20px;
}
</style>
