/* eslint-disable */
/**
 * 本文件由工具自动生成，请勿随意改动！！！
 * @name  wec-devops-image  API
 * @description  镜像中心 
 * @tutorial public/wec-devops-image.yaml
 */
import api from '@api/api'
import http from '@utils/ajax'
import { awaitWrap } from "@utils";

/**
 * get_post
 * @param { Object } params 请求参数
 * @param { String } params['searchContent'] 
 * @param { String } params['verifyStatus'] 
 * @param { String } params['pushStatus'] 
 * @param { Integer } params['pageNumber'] 分页参数，第几页
 * @param { Integer } params['pageSize'] 分页参数，每页显示数量
 */
export const  list =async (params) => {
    // send request
    return awaitWrap(http.post(api.imagemanagev2_list, params))
}

/**
 * get_post
 * @param { Object } params 请求参数
 * @param { String } params['imageWid'] 镜像标识
 */
export const  regionList =async (params) => {
    // send request
    return awaitWrap(http.post(api.imagemanagev2_regionlist, params))
}

/**
 * get_post
 * @param { Object } params 请求参数
 * @param { String } params['imageWid'] 镜像标识
 */
export const  regionSynchronize =async (params) => {
    // send request
    return awaitWrap(http.post(api.imagemanagev2_regionsynchronize, params))
}

