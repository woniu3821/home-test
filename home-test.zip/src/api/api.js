/* eslint-disable */
/**
 * 本文件由工具自动生成，请勿随意改动！！！
 * @name  wec-devops-image  API
 * @description  镜像中心
 * @tutorial public/wec-devops-image.yaml
 */
const DEV_MODE = process.env.NODE_ENV === 'development'

const API_BASE = DEV_MODE ? '' : ''

const _basePath = url => {
    return `${API_BASE}${url}`
}

export default {
    imagemanagev2_list: _basePath('/imageManageV2/list'), // get_post
    imagemanagev2_regionlist: _basePath('/imageManageV2/regionList'), // get_post
    imagemanagev2_regionsynchronize: _basePath('/imageManageV2/regionSynchronize') // get_post
}
